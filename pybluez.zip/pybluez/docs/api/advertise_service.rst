advertise_service
-----------------
.. currentmodule:: bluetooth

.. autofunction:: advertise_service