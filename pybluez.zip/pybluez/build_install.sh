# use python3 
python setup.py bdist_wheel
pip install -U .//dist/PyBluez-0.30-cp37-cp37m-macosx_10_13_x86_64.whl
